<?php

namespace Modules\Paytab\Http\Controllers;

use App\Http\Controllers\SubscriptionController;
use App\Package;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;

class PaytabController extends Controller
{
    /* This function save the api keys to .env file */

    public function saveKeys(Request $request)
    {
        $env = DotenvEditor::setKeys([
            'ENABLE_PAYTAB' => $request->ENABLE_PAYTAB ? 1 : 0,
            'PAYTAB_PROFILE_ID' => $request->PAYTAB_PROFILE_ID,
            'PAYTAB_SERVER_KEY' => $request->PAYTAB_SERVER_KEY
        ]);

        $env->save();

        return back()->with('added', 'Paytabs keys has been updated successfully !');

    }

    /* This function will create payment for paytab and redirect to paytab payment page url on successfull response*/

    public function payment(Request $request){
        
       
        $user = Auth::user();


        Session::put('plan',$request->plan_id);
        Session::put('amount',$request->amount);

        
        $response = Http::withHeaders([
            'Authorization' => config('paytab.PAYTAB_SERVER_KEY')
        ])->post('https://secure-global.paytabs.com/payment/request', [

            'profile_id' => config('paytab.PAYTAB_PROFILE_ID'),
            'tran_type' => 'sale',
            'tran_class' => 'ecom',
            'cart_id' => uniqid(),
            'cart_description' => __("Payment for plan subscription "),
            'cart_currency' => $request->currency,
            'cart_amount' => $request->amount,
            'return' => route("paytabs.callback"),
            'callback' => route("paytabs.callback"),
            "customer_details" => 
            [
                "name"      =>  $user->name,
                "email"     =>  $user->email,
                "phone"     =>  $user->mobile,
                "street1"   =>  'Street',
                "city"      =>  'City',
                "state"     =>  'State',
                "country"   =>  'Country',
                "ip"        =>  $request->ip()
            ],
            "shipping_details" => 
            [
                "name"      =>  $user->name,
                "email"     =>  $user->email,
                "phone"     =>  $user->mobile,
                "street1"   =>  'Street',
                "city"      =>  'City',
                "state"     =>  'State',
                "country"   =>  'Country',
                "ip"        =>  $request->ip()
            ]
        ]);

        if($response->successful())
        {
            $result =  $response->json();
            return  redirect($result['redirect_url']);
        }
        else
        {
            $result = $response->json();
            return back()->with('deleted', $result['message']);
        }
    }

    /** This function verify the signature and capture the transcation id and create new order */

    public function callback(Request $request)
    {
      
       
        

        if ($request->respMessage == 'Authorised') 
        {  

            $txn_id = $request->tranRef;
            
            $plan_id= Session::get('plan');
            $amount = Session::get('amount');
           // Create order if payment is successful
           $checkout = new SubscriptionController;
           return $checkout->subscribe($payment_id=$txn_id,$payment_method='Paytabs',$plan_id,$payment_status=1,$amount); 

        }
        else
        {
            /** Logging the corrupt transcation in laravel.log file */        
            Log::error('Payment failed'.$request->respMessage);
            return redirect('account/purchaseplan')->with('deleted', $request->respMessage);
        }

    }

    /**
     * Open keys setting view
     */
    public function getSettings(){
        return view('paytab::admin.tab');
    }
}
