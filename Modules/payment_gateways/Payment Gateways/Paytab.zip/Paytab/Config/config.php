<?php

return [
    'name' => 'Paytab',
    'PAYTAB_PROFILE_ID' => env('PAYTAB_PROFILE_ID'),
    'ENABLE' => env('ENABLE_PAYTAB'),
    'PAYTAB_SERVER_KEY' => env('PAYTAB_SERVER_KEY')
];
