<!-- This will append Paytabs payment tab on checkout page. -->
<!-- Paytabs payment tab start -->

@if (env('ENABLE_PAYTAB') == 1 && in_array('paytab',$currency_payments) )
    <li>
        <a href="#paytabs_payment_tab" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("Paytabs Payment") }}
        </a>
    </li>
@endif

<!-- Paytabs payment tab end -->