<!-- This will append bkash payment logo on front page. -->
<!-- Bkash owl item start -->
@if(config('paytab.ENABLE') == 1 && Module::has('Paytab') && Module::find('Paytab')->isEnabled())
    <div class="payment-item">
        <a title="{{__('Paytabs Payment')}}" target="__blank" href="https://site.paytabs.com/en/"><img
            data-src="{{ Module::asset('paytab:logo/paytab.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- Bkash owl item end -->