<!-- This will append Paytabs payment tab content on checkout page. -->
<!-- Paytabs payment tab content start -->
<div class="tab-pane" id="paytabs_payment_tab">
    
    @if(config('paytab.ENABLE') == 1)
        <form action="{{ route("paytabs.front.payment") }}" method="POST">
            @csrf

            <!-- Amount -->
            <input type="hidden" name="amount" value="{{ $plan->amount }}">

            <!-- Plan ID -->
            <input type="hidden" name="plan_id" value="{{ $plan->id }}">

            <!-- Currency -->
            <input type="hidden" name="currency" value="{{ $plan->currency }}">

            <!-- Submit Button -->
            <div class="form-group">
                <button class="payment-btn paypal-btn" type="submit" title="checkout">
                    {{__('Pay with PAytab')}} 
                </button>
            </div>
            
        </form>
    @else
        <h4>{{ __("Payment gateway is not enabled yet !") }}</h4>
    @endif

</div>
<!-- Paytabs payment tab content end -->