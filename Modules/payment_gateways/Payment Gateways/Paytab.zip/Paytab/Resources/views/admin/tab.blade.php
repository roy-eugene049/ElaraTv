<!-- This will append Paytabs payment tab content on admin payment settings page. -->
<!-- Paytabs Payment tab content strat -->
@extends('layouts.admin')
@section('title', __('adminstaticwords.APISettings'))

@section('content')
    <div class="admin-form-main-block mrg-t-40">
        <div class="row admin-form-block z-depth-1">
        
            <h6 class="form-block-heading apipadding">{{__('Paytab Payemnt Gateway')}}</h6>
            <a target="__blank" href="https://site.paytabs.com/en/" class="text-white pull-right">
                <i class="fa fa-key"></i>
                {{ __("Get your keys from here") }}</a>
            <br>

            <form action="{{ route('paytabs.payment.setting') }}" method="POST">
                @csrf

                <!-- Profile ID -->
                <div class="form-group">
                    <label>{{ __("PAYTAB PROFILE ID:") }} <span class="text-red">*</span></label>
                    <input required name="PAYTAB_PROFILE_ID" value="{{ config('paytab.PAYTAB_PROFILE_ID') }}" type="text"
                        class="form-control" placeholder="{{ __("Enter PAYTAB PROFILE ID") }}">
                </div>

                <!-- Profile ID -->
                <div class="form-group">
                    <div class="search">
                        <label>{{ __("PAYTAB SERVER KEY:") }} <span class="text-red">*</span></label>
                        <input required type="password" value="{{ config('paytab.PAYTAB_SERVER_KEY') }}" name="PAYTAB_SERVER_KEY" placeholder="{{ __("enter PAYTAB SERVER KEY") }}" id="PAYTAB_SERVER_KEY" type="password"
                            class="form-control">
                        <span toggle="#PAYTAB_SERVER_KEY" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                    </div>
                </div>

                <!-- Status -->
                <div class="form-group">
                    <label> {{__("Status:")}} </label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('ENABLE_PAYTAB', 1, (env('ENABLE_PAYTAB') == 1 ? "checked"  :""), ['id' => 'ENABLE_PAYTAB','class' => 'checkbox-switch']) !!}
                        <span class="slider round"></span>
                    </label>
                </div>


                <!-- Reset / Submit Buttom -->
                <div class="modal-footer">
                    <div class="btn-group pull-right">
                        <a href={{url()->previous()}} class="btn btn-info"><i class="material-icons left">reply</i> {{__('Back')}}</a>
                        <button type="reset" class="btn btn-danger"><i class="material-icons left">toys</i> {{__('adminstaticwords.Reset')}}</button>
                        <button type="submit" class="btn btn-success"><i class="material-icons left">add_to_photos</i> {{__('Save Settings')}}</button>
                    </div>
                </div>
                <div class="clear-both"></div>

            </form>

        </div>
    </div>
@endsection

@section('custom-script')

    <!-- Script for eye icon password - show/hide -->
    <script>

        $(".toggle-password2").click(function() 
        {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } 
            else {
                input.attr("type", "password");
            }
        });

    </script>

@endsection
<!-- Paytabs Payment tab content end -->