<!-- This will append Senangpay payment logo on front page. -->
<!-- Senangpay owl item start -->
@if(config('senangpay.ENABLE') == 1 && Module::has('Senangpay') && Module::find('Senangpay')->isEnabled())
    <div class="payment-item">
        <a title="{{__('Senang Payment')}}" target="__blank" href="https://senangpay.my"><img
            data-src="{{ Module::asset('senangpay:logo/Senangpay.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- Senangpay owl item end -->