<!-- This will append Senang payment tab content on checkout page. -->
<!-- Senang Payment tab content start -->
<div class="tab-pane" id="senang_payment_tab">
    
    @if(config('senangpay.ENABLE') == 1)
        @if(isset(Auth::user()->mobile) && Auth::user()->mobile != NULL)
            <form name="order" method="POST" action="{{ route("senangpay.front.payment") }}">
                @csrf

                <!-- Amount -->
                <input type="hidden" name="amount" value="{{ $plan->amount }}">

                <!-- Plan ID -->
                <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                    
                <!-- Submit Button -->
                <div class="form-group">
                    <button class="payment-btn paypal-btn" type="submit" title="checkout">
                        {{__('Pay with Senangpay')}} 
                    </button>
                </div>
            </form>
        @else
            <p class="text-danger">Please fill your mobile no. 
                <a href="{{url('/account/profile')}}">{{__('clickhere')}}</a>
            </p>
        @endif
        
    @else
        <h4>{{ __("Payment gateway is not enabled yet !") }}</h4>
    @endif

</div>
<!-- Senang Payment tab content end -->