<!-- This will append Senangpay payment tab on checkout page. -->
<!-- Senangpay payment tab start -->

@if (env('SENANGPAY_ENABLE') == 1 && in_array('senangpay',$currency_payments) )
    <li>
        <a href="#senang_payment_tab" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("Senangpay Payment") }}
        </a>
    </li>
@endif

<!-- Senangpay payment tab end -->