<?php

return [
    'name' => __('Senangpay'),
    'ENABLE' => env('SENANGPAY_ENABLE'),
    'SENANGPAY_MERCHANT_ID' => env('SENANGPAY_MERCHANT_ID'),
    'SENANGPAY_SECRET_KEY'  => env('SENANGPAY_SECRET_KEY'),
    'SENANGPAY_MODE' => env('SENANGPAY_MODE','sandbox')
];
