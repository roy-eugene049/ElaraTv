<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Modules\Senangpay\Http\Controllers\SenangpayController;

Route::prefix('senangpay')->group(function() {
    Route::post('/payment', [SenangpayController::class,'payment'])->name('senangpay.front.payment');
    Route::get('/callback',[SenangpayController::class,'callback'])->name('senangpay.callback');
});

Route::group(['middleware' => ['web', 'IsInstalled', 'isActive', 'auth', 'is_admin', 'switch_languages', 'TwoFactor']], function () {

    Route::get('admin/senangpay/payment/show/settings', [SenangpayController::class, 'getSettings'])->name('senangpay.payment.get.setting');
    Route::post('admin/senangpay/payment/settings', [SenangpayController::class, 'saveKeys'])->name('senangpay.payment.setting');

});