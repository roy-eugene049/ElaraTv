<?php

namespace Modules\Senangpay\Http\Controllers;

use App\Http\Controllers\SubscriptionController;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;
use SenangPay\SenangPay;

class SenangpayController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | SenangpayController
    |--------------------------------------------------------------------------
    |
    | All senangpay payment functionality can be found here.
    |
    */

    public function saveKeys(Request $request){

        $env = DotenvEditor::setKeys([
            'SENANGPAY_MERCHANT_ID' => $request->SENANGPAY_MERCHANT_ID,
            'SENANGPAY_SECRET_KEY'  => $request->SENANGPAY_SECRET_KEY,
            'SENANGPAY_ENABLE'      => $request->SENANGPAY_ENABLE ? 1 : 0,
            'SENANGPAY_MODE'        => $request->SENANGPAY_MODE ? "live" : "sandbox"
        ]);

        $env->save();

        return back()->with('added',__('Senangpayment details has been updated !'));
        

    }

    /** This function holds the functionality to proceed the payment */

    public function payment(Request $request)
    {

        $merchant_id = config('senangpay.SENANGPAY_MERCHANT_ID');
        $secret_key  = config('senangpay.SENANGPAY_SECRET_KEY');

        $senangPayUrl = config('senangpay.SENANGPAY_MODE') == 'live' ? 'https://app.senangpay.my' : 'https://sandbox.senangpay.my';

        $senangPay = new SenangPay($merchant_id, $secret_key,$senangPayUrl);

        $amount = $request->amount;

        $paymentUrl = $senangPay->createPayment(
            __('Payment for order'),
            $amount,
            uniqid(),
            [
                'name'  => auth()->user()->name,
                'email' => auth()->user()->email,
                'phone' => auth()->user()->mobile
            ]
        );

        return redirect($paymentUrl);

    }

    /** This function holds the functionality to check the payment */

    public function callback(Request $request)
    {    

        if($request->status == 1)
        {
            $plan_id = $request->plan_id;
            $amount = $request->amount;

            /** Capture the success transaction and place order */
            $checkout = new SubscriptionController;

            return $checkout->subscribe($payment_id=$request->txnre,$payment_method='SenangPay',$plan_id,$payment_status=1,$amount); 

        }
        else
        {
            return redirect('account/purchaseplan')->with('deleted', 'Transaction failed.');
        }

    }

    /**
     * Open keys setting view
     */
    public function getSettings(){
        return view('senangpay::admin.tab');
    }

}
