<?php

return [
    'name'              => 'Esewa',
    'ESEWA_MERCHANT_ID' => env('ESEWA_MERCHANT_ID'),
    'ESEWA_MODE'        => env('ESEWA_MODE','SANDBOX'),
    'ENABLE'      => env('ESEWA_ENABLE',0),
    'ESEWA_PAYURL_SANDBOX' => 'https://uat.esewa.com.np/epay/main',
    'ESEWA_PAYURL_PROD'    => 'https:/esewa.com.np/epay/main'
];
