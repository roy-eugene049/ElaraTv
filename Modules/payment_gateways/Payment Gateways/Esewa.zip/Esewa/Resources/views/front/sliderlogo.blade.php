<!-- This will append bkash payment logo on front page. -->
<!-- Bkash owl item start -->
@if(config('esewa.ENABLE') == 1 && Module::has('Esewa') && Module::find('esewa')->isEnabled())
    <div class="payment-item">
        <a title="{{__('Bkash Payment')}}" target="__blank" href="https://esewa.com.np/"><img
            data-src="{{ Module::asset('esewa:logo/esewa.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- Bkash owl item end -->