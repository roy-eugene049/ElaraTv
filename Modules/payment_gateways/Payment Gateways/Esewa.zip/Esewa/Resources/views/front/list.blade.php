<!-- This will append esewa payment tab on checkout page. -->
<!-- esewa payment tab start -->

@if (env('ESEWA_ENABLE') == 1 && in_array('esewa',$currency_payments) )
    <li>
        <a href="#esewa_payment_tab" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("e-Sewa Payment") }}
        </a>
    </li>
@endif

<!-- esewa payment tab end -->