<!-- This will append esewa payment tab content on checkout page. -->
<!-- esewa payment tab content start -->
<div class="tab-pane" id="esewa_payment_tab">
    
    @if(config('esewa.ENABLE') == 1)

        <form action="{{ env('ESEWA_MODE') == 'SANDBOX' ? "https://uat.esewa.com.np/epay/main" :  "https://esewa.com.np/epay/main" }}" method="POST">
            @csrf

            <!-- Amount -->
            <input value="{{ $plan->amount - $session_amount }}" name="amt" type="hidden">
            <input value="{{ $plan->amount - $session_amount }}" name="tAmt" type="hidden">
            <input value="0" name="txAmt" type="hidden">
            <input value="0" name="psc" type="hidden">
            <input value="0" name="pdc" type="hidden">
            <input value="{{ config('esewa.ESEWA_MERCHANT_ID') }}" name="scd" type="hidden">
            <input value="{{ rand(1000000000,9999999999) }}" name="pid" type="hidden">
            <input value="{{url('account/purchaseplan')}}" type="hidden" name="fu">
            <input value="{{route('esewa.success')}}" type="hidden" name="su">

            <!-- Plan ID -->
            <input id="plan_id" type="hidden" class="form-control" name="plan_id"
                value="{{$plan->id}}">

            
            <!-- Submit Button -->
            <button id="dpo_button" class="payment-btn paypal-btn" type="submit" title="checkout">
                {{__('Pay with Esewa')}} 
            </button>

        </form>
    @else
        <h4>{{ __("e-Sewa payment gateway is not enabled yet !") }}</h4>
    @endif
</div>
