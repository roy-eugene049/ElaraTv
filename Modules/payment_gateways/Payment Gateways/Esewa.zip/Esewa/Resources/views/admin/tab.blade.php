<!-- This will append esewa payment tab content on admin payment settings page. -->
<!-- esewa Payment tab content strat -->
@extends('layouts.admin')
@section('title', __('adminstaticwords.APISettings'))

@section('content')
    <div class="admin-form-main-block mrg-t-40">
        <div class="row admin-form-block z-depth-1">
        
            <h6 class="form-block-heading apipadding">{{__('Esewa Payemnt Gateway')}}</h6>
            <br>

            <form action="{{ route('esewa.payment.setting') }}" method="POST">
                @csrf

                <!-- Merchant ID -->
                <div class="form-group">
                    <div class="search">
                        <label>{{ __("ESEWA MERCHANT ID / Service Code:") }} <span class="text-red">*</span></label>
                        <input required type="password" value="{{ config('esewa.ESEWA_MERCHANT_ID') }}" name="ESEWA_MERCHANT_ID" placeholder="{{ __("Enter ESEWA MERCHANT ID or Service code") }}" id="ESEWA_MERCHANT_ID" type="password"
                            class="form-control">
                        <span toggle="#ESEWA_MERCHANT_ID" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                    </div>
                </div>

                <!-- Status -->
                <div class="form-group">
                    <label>
                        {{__("Enable:")}}
                    </label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('ESEWA_ENABLE', 1, (env('ESEWA_ENABLE') == 1 ? "checked"  :""), ['id' => 'ESEWA_ENABLE','class' => 'checkbox-switch']) !!}
                        <span class="slider round"></span>
                    </label>
                </div>

                <!-- Live/Sandbox -->
                <div class="form-group">
                    <label>
                        {{__("Live Mode:")}}
                    </label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('ESEWA_MODE', 1, (env('ESEWA_MODE') == 'PRODUCTION' ? "checked" : ""), ['id' => 'ESEWA_MODE', 'class' => 'bootswitch', "data-on-text"=>"PRODUCTION", "data-off-text"=>"SANDBOX", "data-size"=>"small"]) !!}
                    </label>
                </div>

                <!-- Reset / Submit Buttom -->
                <div class="modal-footer">
                    <div class="btn-group pull-right">
                        <a href={{url()->previous()}} class="btn btn-info"><i class="material-icons left">reply</i> {{__('Back')}}</a>
                        <button type="reset" class="btn btn-danger"><i class="material-icons left">toys</i> {{__('adminstaticwords.Reset')}}</button>
                        <button type="submit" class="btn btn-success"><i class="material-icons left">add_to_photos</i> {{__('Save Settings')}}</button>
                    </div>
                </div>
                <div class="clear-both"></div>


            </form>
      </div>
  </div>
@endsection

@section('custom-script')

    <!-- Script for eye icon password - show/hide -->
    <script>

        $(".toggle-password2").click(function() 
        {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } 
            else {
                input.attr("type", "password");
            }
        });

    </script>

@endsection
<!-- esewa Payment tab content end -->
