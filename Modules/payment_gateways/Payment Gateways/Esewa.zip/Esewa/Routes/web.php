<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Modules\Esewa\Http\Controllers\EsewaController;

Route::prefix('esewa')->group(function() {

    Route::any('/success', [EsewaController::class,'success'])->name('esewa.success');
    Route::post('/payment/response', [EsewaController::class,'payment_response'])->name('esewa.payment.response');

});

Route::group(['middleware' => ['web', 'IsInstalled', 'isActive', 'auth', 'is_admin', 'switch_languages', 'TwoFactor']], function () {

    Route::get('admin/esewa/payment/show/settings', [EsewaController::class, 'getSettings'])->name('esewa.payment.get.setting');
    Route::post('admin/esewa/payment/settings', [EsewaController::class, 'saveKeys'])->name('esewa.payment.setting');

});
