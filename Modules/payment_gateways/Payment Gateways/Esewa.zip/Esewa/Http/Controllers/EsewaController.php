<?php

namespace Modules\Esewa\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\FailedTranscations;
use App\Http\Controllers\PlaceOrderController;
use App\Http\Controllers\SubscriptionController;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;

class EsewaController extends Controller
{
    /* This function holds the operation to save api keys to env file */

    public function saveKeys(Request $request){

        $input = $request->all();

        $env_keys_save = DotenvEditor::setKeys([
            
            'ESEWA_MERCHANT_ID' => $input['ESEWA_MERCHANT_ID'], 
            'ESEWA_MODE' => $request->ESEWA_MODE ? "PRODUCTION" : 'SANDBOX',
            'ESEWA_ENABLE' => $request->ESEWA_ENABLE ? 1 : 0
        ]);

        $env_keys_save->save();
        
        return back()->with('added', 'e-Sewa payment keys updated !');

    }

    /** This functions holds the functionality to capture the payment and create an order */

    public function success(Request $request)
    {
        
        $plan_id = $request->plan_id;
        $amount = $request->amount;

        if( isset($request->oid) && isset($request->amt) && isset($request->refId))
        {
            
           
            $url = env('ESEWA_MODE') == 'SANDBOX' ? "https://uat.esewa.com.np/epay/transrec" :  "https://esewa.com.np/epay/transrec";  
            

            $data =[
                'amt'=> sprintf("%.2f",$request->amt),
                'rid'=> clean($request->refId),
                'pid'=> clean($request->oid),
                'scd'=> config('esewa.ESEWA_MERCHANT_ID'),
            ];

            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($curl);
            curl_close($curl);

            $response_code = $this->get_xml_node_value('response_code',$response);
            

            if(trim($response_code) == 'Success')
            {
                $checkout = new SubscriptionController;
                return $checkout->subscribe($payment_id=$request->refId,$payment_method='e-Sewa',$plan_id,$payment_status=1,$amount); 
               
            }
            else{
                
                /** Logging failed transcation */
                Log::error('e-Sewa Payment failed !');
                return redirect('account/purchaseplan')->with('deleted', 'Payment Failed');

            }
            
        
        }

    }

    public function get_xml_node_value($node, $xml) {

        if ($xml == false) {
            return false;
        }

        $found = preg_match('#<'.$node.'(?:\s+[^>]+)?>(.*?)'.
                '</'.$node.'>#s', $xml, $matches);

        if ($found != false) {
            
            return $matches[1]; 
             
        }     

        return false;
    }

    /**
     * Open keys setting view
     */
    public function getSettings(){
        return view('esewa::admin.tab');
    }

}
