<?php

return [
    'name'                      => __('sManager'),
    'ENABLE'                    => env('SMANAGER_ENABLE'),
    'SMANAGER_LIVE'             => env('SMANAGER_LIVE'),
    'SMANAGER_CLIENT_ID'        => env('SMANAGER_CLIENT_ID'),
    'SMANAGER_CLIENT_SECRET'    => env('SMANAGER_CLIENT_SECRET')
];
