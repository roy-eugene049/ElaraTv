<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Modules\Smanager\Http\Controllers\SmanagerController;

Route::prefix('smanager')->group(function() {
    Route::post('/payment', [SmanagerController::class,'payment'])->name('smanager.front.payment');
    Route::get('/payment/success', [SmanagerController::class,'success'])->name('smanager.payment.success');
    Route::get('/payment/fail', [SmanagerController::class,'fail'])->name('smanager.payment.fail'); 
});

Route::group(['middleware' => ['web', 'IsInstalled', 'isActive', 'auth', 'is_admin', 'switch_languages', 'TwoFactor']], function () {

    Route::get('admin/smanager/payment/show/settings', [SmanagerController::class, 'getSettings'])->name('smanager.payment.get.setting');
    Route::post('admin/smanager/payment/settings', [SmanagerController::class, 'saveKeys'])->name('smanager.payment.setting');
    
});
