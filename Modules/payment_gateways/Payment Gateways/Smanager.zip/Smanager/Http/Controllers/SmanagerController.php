<?php

namespace Modules\Smanager\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\Smanager\Services\sManagerService;
use App\Http\Controllers\SubscriptionController;
use Illuminate\Support\Facades\Log;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;

class SmanagerController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | SmanagerController
    |--------------------------------------------------------------------------
    |
    | This controller hold the functionality of payment , save payment settings and capture payments.
    |
    */

    /* This function will create payment for Smanager and redirect to Smanager payment page url on successful response*/

    public function payment(Request $request)
    {

        $post_data = array();
        $post_data['total_amount'] = $request->amount; //You cant not pay less than 10
        $post_data['currency'] = $request->currency;
        $post_data['transaction_id'] = uniqid('sM_', true); // tran_id must be unique
        $orderId = $request->plan_id;

        $info = [
            'amount'          => strip_tags($post_data['total_amount']),
            'transaction_id'  => $post_data['transaction_id'],
            'success_url'     => route('smanager.payment.success'),  // success url
            'fail_url'        => route('smanager.payment.fail'),  // failed url
            'customer_name'   => auth()->user()->name,
            'purpose'         => __('Online Transaction'),
            'payment_details' => $orderId,
        ];

        session()->put('sM_transaction_id', $post_data['transaction_id']);

        /** Initiate the payment */
        return sManagerService::initiatePayment($info);
    }


    /** This function verify the signature and capture the transaction id and create new order */

    public function success(Request $request)
    {

        /** Get the transaction id */
        $transactionId = session()->get('sM_transaction_id');

        $responseJSON = sManagerService::paymentDetails($transactionId);

        /** If payment got fails */

        if($responseJSON['data']['payment_status'] !== 'completed')
        {
            Log::error('sManager Payment Error');
            return redirect('account/purchaseplan')->with('deleted', 'Transaction failed.');
        }

        $plan_id = $request->plan_id;
        $amount = $request->amount;

        $txn_id = $transactionId;

        /** Capture the success transaction and place order */
        $checkout = new SubscriptionController;

        return $checkout->subscribe($payment_id=$txn_id,$payment_method='Smanager',$plan_id,$payment_status=1,$amount); 
        
    }

    /** This function handle failed transaction form Paytab payment */

    public function fail(Request $request)
    {

        $request->session()->forget('order_id');
        $request->session()->forget('payment_data');
        $request->session()->forget('sM_transaction_id');

        Log::error('sManager Payment Error');
        return redirect('account/purchaseplan')->with('deleted', 'Payment failed !');
    }


    /** This function handle cancelled transaction form Paytab payment */

    public function cancel(Request $request)
    {
        $request->session()->forget('order_id');
        $request->session()->forget('payment_data');
        $request->session()->forget('sM_transaction_id');
        return redirect('account/purchaseplan')->with('deleted', 'Payment cancelled !');
    }

    public function saveKeys(Request $request){

        $input = $request->all();

        $env_keys_save = DotenvEditor::setKeys([
            
            'SMANAGER_CLIENT_ID'        => $input['SMANAGER_CLIENT_ID'], 
            'SMANAGER_CLIENT_SECRET'    => $input['SMANAGER_CLIENT_SECRET'],
            'SMANAGER_ENABLE'           => $request->SMANAGER_ENABLE ? 1 : 0,
            'SMANAGER_LIVE'             => $request->SMANAGER_LIVE ? "live" : "sandbox"

        ]);

        $env_keys_save->save();
        
        return back()->with('added', 'sManager Payment keys updated !');

    }

    /**
     * Open keys setting view
     */
    public function getSettings(){
        return view('smanager::admin.tab');
    }

}
