<!-- This will append sManager payment tab content on checkout page. -->
<!-- sManager Payment tab content start -->
<div class="tab-pane" id="smanager_payment_tab">

    <form method="POST" action="{{ route('smanager.front.payment') }}" class="form-horizontal" role="form">
        @csrf

        <!-- Amount -->
        <input type="hidden" name="amount" value="{{ $plan->amount }}">

        <!-- Plan ID -->
        <input type="hidden" name="plan_id" value="{{ $plan->id }}">

        <!-- Currency -->
        <input type="hidden" name="currency" value="{{ $plan->currency }}">

        <!-- Submit Button -->
        <div class="form-group">
            <button class="payment-btn paypal-btn" type="submit" title="checkout">
                {{__('Pay with sManager')}} 
            </button>
        </div>

    </form>
    <p class="text-muted">
        <i class="fa fa-lock"></i>
        {{ __('Secured Transcations Powered By sManager Payments') }}
    </p>
</div>
<!-- sManager Payment tab content end -->