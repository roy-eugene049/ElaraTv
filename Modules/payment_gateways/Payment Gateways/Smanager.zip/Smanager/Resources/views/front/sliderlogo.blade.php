<!-- This will append sManager payment logo on front page. -->
<!-- sManager owl item start -->
@if(config('smanager.ENABLE') == 1 && Module::has('Smanager') && Module::find('Smanager')->isEnabled())
    <div class="payment-item">
        <a title="{{__('sManager Payment')}}" target="__blank" href="https://www.smanager.xyz/"><img
            data-src="{{ Module::asset('smanager:logo/smanager.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- sManager owl item end -->