<!-- This will append sManager payment tab on checkout page. -->
<!-- sManager payment tab start -->

@if (env('SMANAGER_ENABLE') == 1 && in_array('smanager',$currency_payments) )
    <li>
        <a href="#smanager_payment_tab" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("sManager Payment") }}
        </a>
    </li>
@endif

<!-- sManager payment tab end -->