<?php

namespace Modules\DPOPayment\Http\Controllers;


use App\FailedTranscations;
use App\Http\Controllers\PreorderController;
use App\Http\Controllers\SubscriptionController;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Session;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;
use SimpleXMLElement;
use Illuminate\Support\Str;


class DPOPaymentController extends Controller
{
    /**
     * Declaring public variables.
     */

    public $result;
    public $transToken;
    public $error;

    /**
     * All global variables which used in this controller only should declared in below function.
     */

    public function __construct()
    {
        $this->gatewayUrl = config('dpopayment.enable_sandbox') == 1 ? config('dpopayment.GATEWAY_URL_SANDBOX') : config('dpopayment.GATEWAY_URL_LIVE');
        $this->companyToken = config('dpopayment.COMPANY_TOKEN');
        $this->serviceType = config('dpopayment.SERVICE_TYPE');
    }

    /**
     * @return auth token to proccess the authorize transcation.
     */

    public function createToken(Request $request)
    {
        $plan_id = $request->plan_id;
        $plan_amount = $request->amount;
        $name = $request->username;
        $email = $request->email;
        $phone = $request->mobile;
        $purpose = 'To Subscribe a Plan';
        $error = 'account/purchaseplan';

        define("REDIRECT_URL", url('/dpo/paymentsuccess'));
        define("BACK_URL", url($error));

        try {
            $type = '1';
            $email = $email;
            $firstName = $name;
            $lastName = $name;
            $amount = $plan_amount;
            $phone = $phone;
            $currency = session()->get('currency')['id'];
            $serviceDesc = $purpose;

            if ($type == "1") {
                $CompanyRef = "<CompanyRef>" . uniqid() . "</CompanyRef>";
            } else if ($type == "2") {
                $CompanyRef = "<CompanyRef>" . uniqid() . "</CompanyRef>";
            }

            $input_xml = "<?xml version='1.0' encoding='utf-8'?>
                        <API3G>
                        <CompanyToken>" . $this->companyToken . "</CompanyToken>
                        <Request>createToken</Request>
                        <Transaction>
                        <customerEmail>" . $email . "</customerEmail>
                        <customerFirstName>" . $firstName . "</customerFirstName>
                        <customerLastName>" . $lastName . "</customerLastName>
                        <customerCity>Gaborone</customerCity>
                        <customerCountry>BW</customerCountry>
                        <customerPhone>" . $phone . "</customerPhone>
                        <EmailTransaction>1</EmailTransaction>
                        <PaymentAmount>" . $amount . "</PaymentAmount>
                        <PaymentCurrency>" . $currency . "</PaymentCurrency>
                        " . $CompanyRef . "
                        <RedirectURL>" . REDIRECT_URL . "</RedirectURL>
                        <BackURL>" . BACK_URL . "</BackURL>
                        <CompanyRefUnique>0</CompanyRefUnique>
                        <PTL>5</PTL>
                        </Transaction>
                        <Services>
                        <Service>
                            <ServiceType>" . $this->serviceType . "</ServiceType>
                            <ServiceDescription>" . $serviceDesc . "</ServiceDescription>
                            <ServiceDate>" . date("Y/m/d H:i") . "</ServiceDate>
                        </Service>
                        </Services>
                        </API3G>";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->gatewayUrl);
            curl_setopt($ch, CURLOPT_POSTFIELDS,
                $input_xml);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
            $data = curl_exec($ch);

            
            curl_close($ch);

            $oXML = new SimpleXMLElement($data);

            foreach ($oXML as $key => $value) {

                if (trim($key) == "Result") {
                    $this->result = $value;
                }

                if (trim($key) == "TransToken") {
                    $this->transToken = $value;
                }

                if(trim($key) == 'ResultExplanation'){
                    $this->error = $value;
                }

            }

            if(config('dpopayment.enable_sandbox') == 1){
               $url = secure_url('https://secure1.sandbox.directpay.online/');
            }else{
               $url = secure_url('https://secure.3gdirectpay.com/');
            }

            if (trim($this->result) == "000") {
                return redirect($url.'payv2.php?ID=' . $this->transToken, 301);
            } else {
                return redirect($error)->with('deleted',$this->error);
            }
        } catch (\Exception $e) {
            notify()->error(trans('Payment failed !'), $e->getMessage());
            return redirect($error);
        }

    }

    /**
     * Payment capture and order placing process.
     */

    public function success(Request $request)
    {

        $plan_id = $request->plan_id;
        $amount = $request->amount;

        $txntoken = strip_tags($request->TransactionToken);
        $CompanyRef = strip_tags($request->CompanyRef);

        $input_xml = "<?xml version='1.0' encoding='utf-8'?>
		<API3G>
		<CompanyToken>" . $this->companyToken . "</CompanyToken>
		<Request>verifyToken</Request>
		<TransactionToken>" . $txntoken . "</TransactionToken>
		<CompanyRef>" . $CompanyRef . "</CompanyRef>
		</API3G>";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->gatewayUrl);
        curl_setopt($ch, CURLOPT_POSTFIELDS,
            $input_xml);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
        $data = curl_exec($ch);
        curl_close($ch);

        $oXML = new SimpleXMLElement($data);

        foreach ($oXML as $key => $value) {

            if (trim($key) == "Result") {
                $this->result = $value;
            }

            if (trim($key) == "ResultExplanation") {
                $this->transToken = $value;
            }

        }

        if ($this->result == '000') {

            /* If payment success and paid */

            $txn_id = $request->TransID;

            $checkout = new SubscriptionController;

            if(Session::get('payment_type') == 'order')
            {
                Session::forget('payment_type');
                Session::forget('error_url');
                Session::forget('order_id');

                $checkout = new SubscriptionController;
                return $checkout->subscribe($payment_id=$txn_id,$payment_method='DPO PAYMENT',$plan_id,$payment_status=1,$amount); 

            }else{
                
                /** Logging failed transcation */
                return redirect('account/purchaseplan')->with('deleted', 'Payment Failed');

            }

        } else {

            /** Logging the failed payment */
            return redirect('account/purchaseplan')->with('deleted', 'Payment Failed');
        }

    }

    /**
     * Update the DPO keys in .env file using this function.
     */

    public function saveSettings(Request $request)
    {

        $request->validate([
            'SERVICE_TYPE' => 'required|string',
            'COMPANY_TOKEN' => 'required|string',
        ]);

        $save = DotenvEditor::setKeys([
            'ENABLE_DPOPAYMENT' => isset($request->ENABLE_DPOPAYMENT) ? 1 : 0,
            'SERVICE_TYPE' => strip_tags($request->SERVICE_TYPE),
            'COMPANY_TOKEN' => strip_tags($request->COMPANY_TOKEN),
            'DPO_SANDBOX' => $request->DPO_SANDBOX == 1 ? "live" : "sandbox"
        ]);

        $save->save();

        return back()->with('added', 'Payment settings updated');

    }

    /**
     * Open DPO keys setting view
     */
    public function getSettings(){
        return view('dpopayment::admin.tab');
    }

}
