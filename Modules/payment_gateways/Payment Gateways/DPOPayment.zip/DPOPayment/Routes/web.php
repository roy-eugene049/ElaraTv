<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group.
|
 */

use Illuminate\Support\Facades\Route;
use Modules\DPOPayment\Http\Controllers\DPOPaymentController;

Route::group(['middleware' => ['isActive', 'IsInstalled', 'switch_languages', 'auth']], function () {
    Route::post('/dpo/payment/proccess', [DPOPaymentController::class, 'createToken'])->name('dpo.payment.process');
    Route::get('/dpo/paymentsuccess', [DPOPaymentController::class, 'success']);
});

Route::group(['middleware' => ['web', 'IsInstalled', 'isActive', 'auth', 'is_admin', 'switch_languages', 'TwoFactor']], function () {

    Route::get('admin/dpo/payment/settings', [DPOPaymentController::class, 'getSettings'])->name('dpopayment.payment.get.setting');
    Route::post('admin/dpo/payment/save/settings', [DPOPaymentController::class, 'saveSettings'])->name('dpopayment.save');

});
