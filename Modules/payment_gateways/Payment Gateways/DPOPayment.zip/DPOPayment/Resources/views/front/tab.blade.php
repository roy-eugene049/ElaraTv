<!-- This will append DPO payment tab content on checkout page.-->
<!-- DPO payment tab content start -->
<div class="tab-pane" id="dpo_payment_front">
    
    @if(config('dpopayment.enable') == 1)
        @if(isset(Auth::user()->mobile) && Auth::user()->mobile != NULL)
            <form action="{{ route('dpo.payment.process') }}" method="POST" autocomplete="off">
                @csrf

                <!-- Amount -->
                <input type="hidden" name="amount" value="{{ $plan->amount - $session_amount }}">

                <!-- Plan ID -->
                <input id="plan_id" type="hidden" class="form-control" name="plan_id"
                    value="{{$plan->id}}">

                <!-- Username -->
                <input id="username" type="hidden" class="form-control" name="username"
                    value="{{auth()->user()->name}}">

                <!-- Email -->
                <input id="email" type="hidden" class="form-control" name="email"
                    value="{{Auth::user()->email}}">

                <!-- Mobile -->
                <input id="mobile" type="hidden" class="form-control" name="mobile"
                    value="{{Auth::user()->mobile}}">

                <!-- Pay button -->
                <button id="dpo_button" class="payment-btn paypal-btn" type="submit" title="checkout">
                    {{__('Pay with DPO')}} 
                </button>
                
            </form>
        @else
            <p class="text-danger">Please fill your mobile no. <a href="{{url('/account/profile')}}">{{__('clickhere')}}</a></p>
        @endif
    @else
        <h4>{{ __("Payment gateway is not enabled yet !") }}</h4>
    @endif

</div>
<!-- DPO payment tab content end -->