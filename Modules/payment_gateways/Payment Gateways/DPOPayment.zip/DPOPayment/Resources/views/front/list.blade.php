<!-- This will append DPO payment tab on checkout page.-->
<!-- DPO Payment tab start -->

@if (env('ENABLE_DPOPAYMENT') == 1 && in_array('dpopayment',$currency_payments) )
    <li>
        <a href="#dpo_payment_front" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("DPO Payment") }}
        </a>
    </li>
@endif

<!-- DPO Payment tab end.-->