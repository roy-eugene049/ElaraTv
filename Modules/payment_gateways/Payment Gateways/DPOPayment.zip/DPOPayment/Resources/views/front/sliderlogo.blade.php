<!-- This will append DPOPayment logo on front page. -->
<!-- DPOPayment owl item start -->
@if(config('dpopayment.enable') == 1 && Module::has('DPOPayment') && Module::find('DPOPayment')->isEnabled())
    <div class="payment-item">
        <a title="{{ __("DPO Payment") }}" target="__blank" href="https://www.dpogroup.com/"><img
            data-src="{{ Module::asset('dpopayment:logo/dpopayment.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- DPOPayment owl item start -->