@extends('layouts.admin')
@section('title', __('adminstaticwords.APISettings'))

@section('content')
    <div class="admin-form-main-block mrg-t-40">
        <div class="row admin-form-block z-depth-1">
        
            <h6 class="form-block-heading apipadding">{{__('DPO Payemnt Gateway')}}</h6>
            <br>

            <form action="{{ route('dpopayment.save') }}" method="POST">
                @csrf

                <!-- Token -->
                <div class="form-group">
                    <div class="search">
                        <label class="text-dark" for="COMPANY_TOKEN">{{ __("COMPANY TOKEN:") }}</label>
                        <!-- --------------- -->
                        <input id="DPO_TOKEN" type="password" class="form-control"  name="COMPANY_TOKEN" value="{{ env('COMPANY_TOKEN') }}" placeholder='{{ __("enter your company token") }}' >
                        <span toggle="#DPO_TOKEN" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                        <!-- --------------- -->
                    </div>
                </div>

                <!-- Service -->
                <div class="form-group">
                    <label class="text-dark">{{ __("SERVICE TYPE:") }}</label>
                    <input required name="SERVICE_TYPE" value="{{ env('SERVICE_TYPE') }}" type="text" class="form-control" placeholder="{{ __("Enter SERVICE TYPE") }}">
                </div>

                <!-- Status -->
                <div class="form-group">
                    <label class="text-dark">{{ __("Status:") }}</label><br>
                    <label class="switch">
                        {!! Form::checkbox('ENABLE_DPOPAYMENT', 1, (config('dpopayment.enable') == 1 ? "checked"  :""), ['id' => 'ENABLE_DPOPAYMENT','class' => 'checkbox-switch']) !!}
                        <span class="slider round"></span>
                    </label><br>
                    
                    <small>{{__("(Active or deactive payment gateway by toggling it.)")}}</small>
                </div>

                <!-- Live/Sandbox -->
                <div class="form-group">
                    <label class="text-dark">{{ __("Sandbox (TEST MODE):") }}</label><br>
                    <label class="switch">
                        {!! Form::checkbox('DPO_SANDBOX', 1, (config('dpopayment.enable_sandbox') == 'live' ? "checked" : ""), ['id' => 'DPO_SANDBOX', 'class' => 'bootswitch', "data-on-text"=>"Live", "data-off-text"=>"Sandbox", "data-size"=>"small"]) !!}
                    </label><br>
                
                    <small>{{ __("(Active or deactive test mode in payment gateway by toggling it.)") }}</small>
                </div>

                <!-- Reset / Submit Buttom -->
                <div class="modal-footer">
                    <div class="btn-group pull-right">
                        <a href={{url()->previous()}} class="btn btn-info"><i class="material-icons left">reply</i> {{__('Back')}}</a>
                        <button type="reset" class="btn btn-danger"><i class="material-icons left">toys</i> {{__('adminstaticwords.Reset')}}</button>
                        <button type="submit" class="btn btn-success"><i class="material-icons left">add_to_photos</i> {{__('Save Settings')}}</button>
                    </div>
                </div>
                <div class="clear-both"></div>

            </form>

        </div>
    </div>
@endsection

@section('custom-script')

    <!-- Script for eye icon password - show/hide -->
    <script>

        $(".toggle-password2").click(function() 
        {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } 
            else {
                input.attr("type", "password");
            }
        });

    </script>

@endsection