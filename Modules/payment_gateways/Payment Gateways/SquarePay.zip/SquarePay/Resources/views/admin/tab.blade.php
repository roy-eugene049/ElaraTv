<!-- This will append Squarepay payment tab content on admin payment settings page. -->
<!-- Squarepay Payment tab content strat -->
@extends('layouts.admin')
@section('title', __('adminstaticwords.APISettings'))

@section('content')
    <div class="admin-form-main-block mrg-t-40">
        <div class="row admin-form-block z-depth-1">

            <h6 class="form-block-heading apipadding">{{__('Squarepay Payemnt Gateway')}}</h6>
            <br>

            <form action="{{ route('squarepay.payment.setting') }}" method="POST">
                @csrf

                <!-- Location ID -->
                <div class="form-group">
                    <label>{{ __("SQUARE PAY LOCATION ID:") }}</label>
                    <input required name="SQUARE_PAY_LOCATION_ID" value="{{ env('SQUARE_PAY_LOCATION_ID') }}" type="text" class="form-control" placeholder="{{ __("Enter SQUARE PAY LOCATION ID") }}">
                </div>

                <!-- Access Token -->
                <div class="form-group">
                    <div class="search">
                        <label for="SQUARE_ACCESS_TOKEN">{{ __("SQUARE PAY APP ACCESS TOKEN:") }}</label>
                        <input required type="password" value="{{ env('SQUARE_ACCESS_TOKEN') }}" name="SQUARE_ACCESS_TOKEN"
                            placeholder="{{ __("Enter SQUARE PAY ACCESS TOKEN") }}" id="SQUARE_ACCESS_TOKEN" type="password"
                            class="form-control">
                        <span toggle="#SQUARE_ACCESS_TOKEN" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                    </div>
                </div>

                <!-- Application ID -->
                <div class="form-group">
                    <label>{{ __("SQUARE APPLICATION ID:") }}</label>
                    <input required name="SQUARE_APPLICATION_ID" value="{{ env('SQUARE_APPLICATION_ID') }}" type="text" class="form-control" placeholder="{{ __("Enter SQUARE PAY APPLICATION ID") }}">
                </div>

                <!-- Status -->
                <div class="form-group">
                    <label>{{ __("Status:") }}</label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('SQUARE_PAY_ENABLE', 1, (env('SQUARE_PAY_ENABLE') == 1 ? "checked"  :""), ['id' => 'SQUARE_PAY_ENABLE','class' => 'checkbox-switch']) !!}
                        <span class="slider round"></span>
                    </label>
                    <br>
                    <small class="txt-desc">
                        {{__("(Active or deactive payment gateway by toggling it.)")}}
                    </small>
                </div>

                <!-- Live/Sandbox -->
                <div class="form-group">
                    <label>{{ __("Live:") }}</label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('SQUARE_PAY_LIVE', 1, (env('SQUARE_PAY_LIVE') == 'live' ? "checked" : ""), ['id' => 'SQUARE_PAY_LIVE', 'class' => 'bootswitch', "data-on-text"=>"LIVE", "data-off-text"=>"SANDBOX", "data-size"=>"small"]) !!}
                    </label>
                    <br>
                    <small class="txt-desc">
                        {{__("(Active or deactive payment gateway live mode.)")}}
                    </small>
                </div>

                <!-- Reset / Submit Buttom -->
                <div class="modal-footer">
                    <div class="btn-group pull-right">
                        <a href={{url('admin/addon-manger')}} class="btn btn-info"><i class="material-icons left">reply</i> {{__('Back')}}</a>
                        <button type="reset" class="btn btn-danger"><i class="material-icons left">toys</i> {{__('adminstaticwords.Reset')}}</button>
                        <button type="submit" class="btn btn-success"><i class="material-icons left">add_to_photos</i> {{__('Save Settings')}}</button>
                    </div>
                </div>
                <div class="clear-both"></div>

            </form>
        </div>
    </div>
@endsection

@section('custom-script')

    <!-- Script for eye icon password - show/hide -->
    <script>

        $(".toggle-password2").click(function() 
        {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } 
            else {
                input.attr("type", "password");
            }
        });

    </script>

@endsection
<!-- Squarepay Payment tab content end -->