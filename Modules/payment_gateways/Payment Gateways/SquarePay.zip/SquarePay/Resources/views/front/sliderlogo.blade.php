<!-- This will append SquarePay payment logo on front page. -->
<!-- SquarePay owl item start -->
@if(config('squarepay.ENABLE') == 1 && Module::has('SquarePay') && Module::find('SquarePay')->isEnabled())
    <div class="payment-item">
        <a title="{{__('SquarePay Payment')}}" target="__blank" href="https://developer.squareup.com/"><img
            data-src="{{ Module::asset('squarepay:logo/bkash.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- SquarePay owl item end -->