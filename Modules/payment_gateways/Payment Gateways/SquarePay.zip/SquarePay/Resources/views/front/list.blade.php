<!-- This will append Squarepay payment tab on checkout page. -->
<!-- Squarepay payment tab start -->

@if (env('SQUARE_PAY_ENABLE') == 1 && in_array('squarepay',$currency_payments) )
    <li>
        <a href="#sqp_payment_tab" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("SquarePay Payment") }}
        </a>
    </li>
@endif

<!-- Squarepay payment tab end -->