<!-- This will append Squarepay payment tab content on checkout page. -->
<!-- Squarepay payment tab content start -->

<div class="tab-pane" id="sqp_payment_tab">
    @if(config('squarepay.ENABLE') == 1)
         
        <form id="sqp-payment-form" method="POST" action="{{ route('squarepay.front.payment') }}">
            @csrf
            
            <!-- Amount -->
            <input type="hidden" name="amount" value="100">

            <!-- Plan ID -->
            <input type="hidden" name="plan_id" value="{{ $plan->id }}">

            <!-- Currency -->
            <input type="hidden" name="currency" value="{{ $plan->currency }}">
            
            <div id="sqp_card_container"></div>
        
            <input id="sqp_txn" type="hidden" value="" name="txn_id">
            
            <!-- Submit Button -->
            <div class="form-group">
                <button class="payment-btn paypal-btn" type="button" id="card-button">
                    {{__('Pay with Squarepay')}} 
                </button>
            </div>

        </form>
        <div id="payment-status-container"></div>
     
    @else
        <h4>{{ __("Squarepay Payment gateway is not enabled yet !") }}</h4>
    @endif
</div>

<!-- Squarepay payment tab content end -->
@push('addon-script')
    <script src="//cdnjs.cloudflare.com/ajax/libs/axios/0.21.1/axios.min.js" integrity="sha512-bZS47S7sPOxkjU/4Bt0zrhEtWx0y0CRkhEp8IckzK+ltifIIE9EMIMTuT/mEzoIMewUINruDBIR/jJnbguonqQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://sandbox.web.squarecdn.com/v1/square.js"></script>
    <script>

        const appId      = @json(config('squarepay.SQUARE_APPLICATION_ID'));
        const locationId = @json(config('squarepay.SQUARE_PAY_LOCATION_ID')); 
        
            async function initializeCard(payments) {

            const card = await payments.card();

            await card.attach('#sqp_card_container'); 
                return card; 
            }

            document.addEventListener('DOMContentLoaded', async function () {
                if (!window.Square) {
                    throw new Error('Square.js failed to load properly');
                }
                const payments = window.Square.payments(appId, locationId);

                let card;
                try {
                    card = await initializeCard(payments);
                } catch (e) {
                    console.error('Initializing Card failed', e);
                    return;
                }

                async function handlePaymentMethodSubmission(event, paymentMethod) {
                event.preventDefault();

                    try {

                        cardButton.disabled = true;
                        const token = await tokenize(paymentMethod);
                        const paymentResults = await createPayment(token);

                        if(paymentResults.payment.id){

                            $('#sqp_txn').val(paymentResults.payment.id);

                            $('#sqp-payment-form').submit();
                        }

                    } catch (e) {
                        cardButton.disabled = false;
                        displayPaymentResults('FAILURE');
                        console.log(e.message);
                    }
                }

                const cardButton = document.getElementById(
                    'card-button'
                );

                cardButton.addEventListener('click', async function (event) {
                    await handlePaymentMethodSubmission(event, card);
                });


            // Step 5.2: create card payment
            });

            async function createPayment(token) {

                const body = JSON.stringify({
                    __token : '{{ csrf_token() }}',
                    locationId,
                    sourceId: token,
                    amount : @json($plan->amount),
                    currency : @json($plan->currency)
                });

                return await axios.post('{{ url("/squarepay/create/payment") }}',body,{
                    headers: {
                        'Content-Type': 'application/json',
                    }
                })
                .then(res => {
                    return res.data;
                })
                .catch(err => {
                   return err.data;
                });

            }

            // This function tokenizes a payment method. 
            // The ‘error’ thrown from this async function denotes a failed tokenization,
            // which is due to buyer error (such as an expired card). It is up to the
            // developer to handle the error and provide the buyer the chance to fix
            // their mistakes.
            async function tokenize(paymentMethod) {
                const tokenResult = await paymentMethod.tokenize();
                if (tokenResult.status === 'OK') {
                    return tokenResult.token;
                } else {
                    let errorMessage = `Tokenization failed-status: ${tokenResult.status}`;
                    if (tokenResult.errors) {
                    errorMessage += ` and errors: ${JSON.stringify(
                        tokenResult.errors
                    )}`;
                    }
                    throw new Error(errorMessage);
                }
            }

            function displayPaymentResults(status) {
                const statusContainer = document.getElementById(
                    'payment-status-container'
                );
                if (status === 'SUCCESS') {
                    statusContainer.classList.remove('is-failure');
                    statusContainer.classList.add('is-success');
                } else {
                    statusContainer.classList.remove('is-success');
                    statusContainer.classList.add('is-failure');
                }

                statusContainer.style.visibility = 'visible';
            }   


    </script>
@endpush
