<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;
use Modules\Bkash\Http\Controllers\BkashController;

Route::group(['middleware' => ['isActive', 'IsInstalled', 'switch_languages', 'auth']], function () {
    Route::get('/bkash_token', [BkashController::class, 'getToken']);
    Route::post('/bkash/checkout', [BkashController::class, 'createPayment']);
    Route::post('/bkash/execute', [BkashController::class, 'executePayment']);
    Route::get('/bkash/success', [BkashController::class, 'success']);
});

Route::group(['middleware' => ['web', 'IsInstalled', 'isActive', 'auth', 'is_admin', 'switch_languages', 'TwoFactor']], function () {

    Route::get('admin/bkash/payment/show/settings', [BkashController::class, 'getSettings'])->name('bkash.payment.get.setting');
    Route::post('admin/bkash/payment/settings', [BkashController::class, 'saveKeys'])->name('bkash.payment.setting');

});
