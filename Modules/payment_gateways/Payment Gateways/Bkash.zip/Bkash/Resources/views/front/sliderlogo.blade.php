<!-- This will append bkash payment logo on front page. -->
<!-- Bkash owl item start -->
@if(config('bkash.ENABLE') == 1 && Module::has('Bkash') && Module::find('Bkash')->isEnabled())
    <div class="payment-item">
        <a title="{{__('Bkash Payment')}}" target="__blank" href="https://www.bkash.com/"><img
            data-src="{{ Module::asset('bkash:logo/bkash.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- Bkash owl item end -->