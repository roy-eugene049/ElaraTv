<!-- This will append bkash payment tab on checkout page. -->
<!-- Bkash payment tab start -->
<!--    -->

@if (env('ENABLE_BKASH') == 1 && in_array('bkash',$currency_payments) )
    <li>
        <a href="#bkash_payment_tab" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("Bkash Payment") }}
        </a>
    </li>
@endif

<!-- Bkash payment tab end -->