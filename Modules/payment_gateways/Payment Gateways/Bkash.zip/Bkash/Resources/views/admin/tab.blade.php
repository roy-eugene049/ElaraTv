@extends('layouts.admin')
@section('title', __('adminstaticwords.APISettings'))

@section('content')
    <div class="admin-form-main-block mrg-t-40">
        <div class="row admin-form-block z-depth-1">
        
            <h6 class="form-block-heading apipadding">{{__('Bkash Payemnt Gateway')}}</h6>
            <br>
            <form action="{{ route('bkash.payment.setting') }}" method="POST">
                @csrf

                <!-- Key -->
                <div class="form-group">
                    <label class="text-dark">{{ __("BKASH APP KEY:") }}</label>
                    <input required name="BKASH_APP_KEY" value="{{ env('BKASH_APP_KEY') }}" type="text"
                        class="form-control" placeholder="{{ __("Enter bkash app key") }}">
                </div>

                <!-- Secret Key -->
                <div class="form-group">
                    <div class="search">
                        <label class="text-dark" for="BKASH_APP_SECRET">{{ __("BKASH APP SECRET:") }}</label>
                        <!-- --------------- -->
                        <input type="password" class="form-control"  name="BKASH_APP_SECRET" value="{{ env('BKASH_APP_SECRET') }}" placeholder='{{ __("enter bkash app secret") }}' id="BKASH_APP_SECRET">
                        <span toggle="#BKASH_APP_SECRET" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                        <!-- --------------- -->
                    </div>
                </div>
                
                <!-- Username -->
                <div class="form-group">
                    <label class="text-dark">{{ __("BKASH USER NAME:") }}</label>
                    <input required name="BKASH_USER_NAME" value="{{ env('BKASH_USER_NAME') }}" type="text"
                        class="form-control" placeholder="{{ __("Enter bkash username") }}">
                </div>

                <!-- Password -->
                <div class="form-group">
                    <div class="search">

                        <label class="text-dark" for="BKASH_PASSWORD">{{ __("BKASH APP Password:") }}</label>
                        <!-- --------------- -->
                        <input id="pass_log_id192" type="password" class="form-control"  name="BKASH_PASSWORD" value="{{ env('BKASH_PASSWORD') }}" >
                        <span toggle="#pass_log_id192" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                        <!-- --------------- -->

                    </div>
                </div>

                <!-- Status -->
                <div class="form-group">
                    <label class="text-dark">{{ __("Status:") }}</label><br>
                    <label class="switch">
                        {!! Form::checkbox('ENABLE_BKASH', 1, (config('bkash.ENABLE') == 1 ? "checked"  :""), ['id' => 'ENABLE_BKASH','class' => 'checkbox-switch']) !!}
                        <span class="slider round"></span>
                    </label><br>

                    <small>
                        {{__("(Active or deactive payment gateway by toggling it.)")}}
                    </small>
                </div>

                <!-- Live/Sandbox -->
                <div class="form-group">
                    <label class="text-dark">{{ __("SANDBOX Mode (TEST Mode):") }}</label>
                    <br>
                    <div class="make-switch">
                        {!! Form::checkbox('BKASH_SANDBOX_MODE', 1, (config('bkash.SANDBOX_ENABLED') == 'live' ? "checked" : ""), ['id' => 'BKASH_SANDBOX_MODE', 'class' => 'bootswitch', "data-on-text"=>"Live", "data-off-text"=>"Sandbox", "data-size"=>"small"]) !!}
                    </div>
                    <br>
                        
                    <small class="txt-desc">
                        {{__("(Active or deactive test mode in payment gateway by toggling it.)")}}
                    </small>
                </div>

                <!-- Reset / Submit / Back Buttom -->
                <div class="modal-footer">
                    <div class="btn-group pull-right">
                        <a href={{url()->previous()}} class="btn btn-info"><i class="material-icons left">reply</i> {{__('Back')}}</a>
                        <button type="reset" class="btn btn-danger"><i class="material-icons left">toys</i> {{__('adminstaticwords.Reset')}}</button>
                        <button type="submit" class="btn btn-success"><i class="material-icons left">add_to_photos</i> {{__('Save Settings')}}</button>
                    </div>
                </div>
                <div class="clear-both"></div>

            </form>

        </div>
    </div>
@endsection

@section('custom-script')

    <!-- Script for eye icon password - show/hide -->
    <script>

        $(".toggle-password2").click(function() 
        {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } 
            else {
                input.attr("type", "password");
            }
        });

    </script>

@endsection