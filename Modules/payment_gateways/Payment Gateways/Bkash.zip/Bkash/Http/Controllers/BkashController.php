<?php

namespace Modules\Bkash\Http\Controllers;

use App\FailedTranscations;
use App\Http\Controllers\SubscriptionController;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;


class BkashController extends Controller
{
    /**
     * All global variables which used in this controller only should declared in below function.
     */

    public function __construct()
    {
        $this->url = config('bkash.SANDBOX_ENABLED') == 1 ? config('bkash.SANDBOX_URL') : config('bkash.LIVE_URL');
        $this->username = config('bkash.BKASH_USER_NAME');
        $this->password = config('bkash.BKASH_PASSWORD');
        $this->appkey = config('bkash.BKASH_APP_KEY');
        $this->apppassword = config('bkash.BKASH_APP_SECRET');
    }

    /**
     * @return auth token to proccess the authorize transcation.
     */

    public function getToken()
    {
        
       return  $response = Http::withHeaders([
            'username' => $this->username,
            'password' => $this->password,
        ])->post($this->url . '/checkout/token/grant', [
            'app_key' => $this->appkey,
            'app_secret' => $this->apppassword,
        ]);
        
        if ($response->successful()) {

            $result = $response->json();

            session()->put('bkash_token', $result['id_token']);

            return $result['id_token'];

        } else {

            return response()->json(__('Token can\'t created'), 401);

        }

    }

    /**
     * Create payment and send payment request to bkash api
     */

    public function createPayment()
    {

        $payment = Http::withHeaders([
            'Authorization' => $this->getToken(),
            'X-APP-Key' => $this->appkey,
        ])->post($this->url . '/checkout/payment/create', [
            'amount' => 100,
            'currency' => 'BDT',
            'intent' => 'sale',
            'merchantInvoiceNumber' => uniqid(),
        ]);

        if ($payment->successful()) {
            return $payment->body();
        }
    }

    /**
     * Execute payment get payment response from bkash api.
     */

    public function executePayment(Request $request)
    {

        $payment = Http::withHeaders([
            'Content-Type:application/json',
            'Authorization' => session()->get('bkash_token'),
            'X-APP-Key' => $this->appkey,
        ])->post($this->url . '/checkout/payment/execute/' . $request->paymentID);

        if ($payment->successful()) {
            return $payment->body();
        }

    }

    /**
     * Get Transcation response on callback and prepare for order placing process.
     */

    public function success(Request $request)
    {

        $plan_id = $request->plan_id;
        $amount = $request->amount;
        
        /* Decoding the response */

        $result = json_decode($request->payment_details, true);

        if ($result['transactionStatus'] == 'Completed') {

            $txn_id = $result['paymentID'];

            $payment_status = __("yes");

            /* Placing new order */

            $checkout = new SubscriptionController;
            return $checkout->subscribe($payment_id=$txn_id,$payment_method='Bkash',$plan_id,$payment_status=1,$amount); 

        } else {

            /** Logging failed transcation */
            return redirect('account/purchaseplan')->with('deleted', 'Payment Failed');

        }
    }

    /**
     * Update the Bkash keys in .env file using this function.
     */

    public function saveKeys(Request $request)
    {
        $save = DotenvEditor::setKeys([
            'BKASH_APP_KEY' => strip_tags($request->BKASH_APP_KEY),
            'BKASH_APP_SECRET' => strip_tags($request->BKASH_APP_SECRET),
            'BKASH_USER_NAME' => strip_tags($request->BKASH_USER_NAME),
            'BKASH_PASSWORD' => strip_tags($request->BKASH_PASSWORD),
            'ENABLE_BKASH' => isset($request->ENABLE_BKASH) ? 1 : 0,
            'BKASH_SANDBOX_MODE' => $request->BKASH_SANDBOX_MODE == 1 ? "live" : "sandbox",
        ]);

        $save->save();

        return back()->with('added', 'Bkash Payment settings updated !');

    }

    /**
     * Open keys setting view
     */
    public function getSettings(){
        return view('bkash::admin.tab');
    }

}
