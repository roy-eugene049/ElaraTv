<!-- This will append Midtrains payment logo on front page. -->
<!-- Midtrains owl item start -->
@if(config('midtrains.ENABLE') == 1 && Module::has('Midtrains') && Module::find('Midtrains')->isEnabled())
    <div class="payment-item">
        <a title="{{__('Midtrains Payment')}}" target="__blank" href="https://midtrans.com/"><img
            data-src="{{ Module::asset('midtrains:logo/midtrains.png') }}" class="owl-lazy img-fluid"></a>
    </div>              
@endif
<!-- Midtrains owl item end -->