<!-- This will append Midtrains payment tab on checkout page. -->
<!-- Midtrains payment tab start -->

@if (env('MID_TRANS_ENABLE') == 1 && in_array('midtrains',$currency_payments) )
    <li>
        <a href="#midtrains_payment_tab" data-toggle="tab">
            {{ __('staticwords.CheckoutWith') }} {{ __("Midtrains Payment") }}
        </a>
    </li>
@endif
<!-- Midtrains payment tab end -->

