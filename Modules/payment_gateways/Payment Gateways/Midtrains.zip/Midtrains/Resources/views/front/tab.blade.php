<!-- This will append esewa payment tab content on checkout page. -->
<!-- midtrains payment tab content start -->
<div class="tab-pane" id="midtrains_payment_tab">
    
    <form id="midtrans-payment-form" method="post" action="{{ route("midtrains.front.payment") }}">
        @csrf
        {{-- <input type="hidden" name="actualtotal" value="{{ strip_tags($un_sec) }}"> --}}
        <input type="hidden" name="amount" value="{{ $plan->amount - $session_amount }}">
        <input type="hidden" name="plan_id" value="{{ $plan->id }}">
        <input type="hidden" name="result_type" id="result-type" value="">
        <input type="hidden" name="result_data" id="result-data" value="">
    </form>

    <!-- Submit Button -->
    <div>
    <button id="pay-button-midtrans" class="payment-btn paypal-btn" type="submit" title="checkout">
        {{__('Pay with Midtrains')}} 
    </button>
    <br>
    <p class="text-muted"><i class="fa fa-lock"></i>
        {{ __('Secured Transcations Powered By Midtrans Payments') }}</p>
    </div>

</div>

<!-- Addon Script -->
@push('addon-script')
    <script type="text/javascript" src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ config('midtrains.MID_TRANS_CLIENT_KEY') }}">
    </script>
    <script>
        "use Strict";
        
        $('#pay-button-midtrans').on('click', function (event) {
            event.preventDefault();
            $(this).attr("disabled", "disabled");

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({

                url: @json(route("midtrains.get.token")),
                cache: false,
                method: 'POST',
                data: {
                    amount: @json($plan->amount)
                },
                success: function (data) {

                    data = $.trim(data);

                    var resultType = document.getElementById('result-type');
                    var resultData = document.getElementById('result-data');

                    function changeResult(type, data) {
                        $("#result-type").val(type);
                        $("#result-data").val(JSON.stringify(data));
                    }

                    snap.pay(data, {

                        onSuccess: function (result) {
                            changeResult('success', result);
                            console.log(result.status_message);
                            console.log(result);
                            $("#midtrans-payment-form").submit();
                        },
                        onPending: function (result) {
                            changeResult('pending', result);
                            console.log(result.status_message);
                            $("#midtrans-payment-form").submit();
                        },
                        onError: function (result) {
                            changeResult('error', result);
                            console.log(result.status_message);
                            $("#midtrans-payment-form").submit();
                        }
                    });
                }
            });
        });
    </script>
@endpush