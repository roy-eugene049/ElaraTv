<!-- This will append Midtrains payment tab content on admin payment settings page. -->
<!-- Midtrains Payment tab content strat -->
@extends('layouts.admin')
@section('title', __('adminstaticwords.APISettings'))

@section('content')
    <div class="admin-form-main-block mrg-t-40">
        <div class="row admin-form-block z-depth-1">
        
            <h6 class="form-block-heading apipadding">{{__('Midtrains Payemnt Gateway')}}</h6>
            <br>

            <form action="{{ route('midtrains.payment.setting') }}" method="POST">
                @csrf

                <!-- Client Key -->
                <div class="form-group">
                    <label>{{ __("MID TRANS CLIENT KEY:") }} <span class="text-red">*</span></label>
                    <input required name="MID_TRANS_CLIENT_KEY" value="{{ config('midtrains.MID_TRANS_CLIENT_KEY') }}" type="text"
                        class="form-control" placeholder="{{ __("Enter midtrains client id") }}">
                </div>

                <!-- Server Key -->
                <div class="form-group">
                    <div class="search">
                        <label>{{ __("MID TRANS SERVER KEY:") }} <span class="text-red">*</span></label>
                        <input required type="password" value="{{ config('midtrains.MID_TRANS_SERVER_KEY') }}" name="MID_TRANS_SERVER_KEY" placeholder="{{ __("enter worldpay secret key") }}" id="MID_TRANS_SERVER_KEY" type="password"
                            class="form-control">
                        <span toggle="#MID_TRANS_SERVER_KEY" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                    </div>
                </div>

                <!-- Status -->
                <div class="form-group">
                    <label> {{__("Status:")}} </label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('MID_TRANS_ENABLE', 1, (env('MID_TRANS_ENABLE') == 1 ? "checked"  :""), ['id' => 'MID_TRANS_ENABLE','class' => 'checkbox-switch']) !!}
                        <span class="slider round"></span>
                    </label>
                </div>

                <!-- Live/Sandbox -->
                <div class="form-group">
                    <label>
                        {{ __("Live Mode:") }}
                    </label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('MID_TRANS_MODE', 1, (env('MID_TRANS_MODE') == 'live' ? "checked" : ""), ['id' => 'MID_TRANS_MODE', 'class' => 'bootswitch', "data-on-text"=>"PRODUCTION", "data-off-text"=>"SANDBOX", "data-size"=>"small"]) !!}
                    </label>
                </div>

                <!-- Reset / Submit Buttom -->
                <div class="modal-footer">
                    <div class="btn-group pull-right">
                        <a href={{url()->previous()}} class="btn btn-info"><i class="material-icons left">reply</i> {{__('Back')}}</a>
                        <button type="reset" class="btn btn-danger"><i class="material-icons left">toys</i> {{__('adminstaticwords.Reset')}}</button>
                        <button type="submit" class="btn btn-success"><i class="material-icons left">add_to_photos</i> {{__('Save Settings')}}</button>
                    </div>
                </div>
                <div class="clear-both"></div>

            </form>

        </div>
    </div>
@endsection

@section('custom-script')

    <!-- Script for eye icon password - show/hide -->
    <script>

        $(".toggle-password2").click(function() 
        {
            $(this).toggleClass("fa-eye fa-eye-slash");
            var input = $($(this).attr("toggle"));
            if (input.attr("type") == "password") {
                input.attr("type", "text");
            } 
            else {
                input.attr("type", "password");
            }
        });

    </script>

@endsection
<!-- Midtrains Payment tab content end -->