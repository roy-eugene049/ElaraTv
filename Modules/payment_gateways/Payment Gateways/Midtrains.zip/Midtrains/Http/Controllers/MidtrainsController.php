<?php

namespace Modules\Midtrains\Http\Controllers;

use App\Http\Controllers\SubscriptionController;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Log;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;
use Modules\Midtrains\Veritrans\Midtrans;

class MidtrainsController extends Controller
{

    public function __construct()
    {
        Midtrans::$serverKey = config('midtrains.MID_TRANS_SERVER_KEY');
        Midtrans::$isProduction = config('midtrains.MID_TRANS_MODE') == 'sandbox' ? false : true;

    }

    /** This function holds process of token*/

    public function token(Request $request)
    {
        $midtrans = new Midtrans;
        
        $transaction_details = array(
            'order_id' => uniqid(),
            'gross_amount' => $request->amount,
        );

        // Populate items
        $items = array(
            array(
                'id' => 'item1',
                'price' => $request->amount,
                'quantity' => 1,
                'name' => auth()->user()->name,
            ),
        );

        // Populate customer's Info
        $customer_details = array(
            'first_name' => auth()->user()->name,
            'last_name' => auth()->user()->name,
            'email' => auth()->user()->email,
            'phone' => auth()->user()->mobile,
            'billing_address' => '',
            'shipping_address' => '',
        );

        // Data yang akan dikirim untuk request redirect_url.
        $credit_card['secure'] = true;
        //ser save_card true to enable oneclick or 2click

        $time = time();
        $custom_expiry = array(
            'start_time' => date("Y-m-d H:i:s O", $time),
            'unit' => 'hour',
            'duration' => 2,
        );

        $transaction_data = array(
            'transaction_details' => $transaction_details,
            'item_details' => $items,
            'customer_details' => $customer_details,
            'credit_card' => $credit_card,
            'expiry' => $custom_expiry,
        );

        try
        {
            $snap_token = $midtrans->getSnapToken($transaction_data);
            return $snap_token;
        } 
        catch (\Exception $e) 
        {
            return $e->getMessage();
        }
    }

    /** This function holds the payment success and create order process */
    public function payment(Request $request)
    {
        
        $plan_id = $request->plan_id;
        $amount = $request->amount;

        $result = $request->input('result_data');
        // return $result;
        $result = json_decode($result);
        if($result->status_code == 200)
        {
            /** Capture the success transaction and place order */
            $checkout = new SubscriptionController;
            return $checkout->subscribe($payment_id=$result->transaction_id,$payment_method='Midtrans',$plan_id,$payment_status=1,$amount); 

        }
        else
        {
            /** Logging the failed transcation */
            Log::error('Midtrans Payment Error: Charge Credit Card ERROR :'.$result->status_message);
            return redirect('account/purchaseplan')->with('deleted', 'Payment Failed');

        }
    }

    /* This function holds the operation to save api keys to env file */
    public function saveKeys(Request $request)
    {

        $input = $request->all();

        $env_keys_save = DotenvEditor::setKeys([

            'MID_TRANS_CLIENT_KEY' => $input['MID_TRANS_CLIENT_KEY'],
            'MID_TRANS_SERVER_KEY' => $input['MID_TRANS_SERVER_KEY'],
            'MID_TRANS_MODE' => $request->MID_TRANS_MODE ? 'live' : 'sandbox',
            'MID_TRANS_ENABLE' => $request->MID_TRANS_ENABLE ? 1 : 0,

        ]);

        $env_keys_save->save();

        return back()->with('added', 'MidTrains payment keys updated !');

    }

    /**
     * Open keys setting view
     */
    public function getSettings(){
        return view('midtrains::admin.tab');
    }
}
