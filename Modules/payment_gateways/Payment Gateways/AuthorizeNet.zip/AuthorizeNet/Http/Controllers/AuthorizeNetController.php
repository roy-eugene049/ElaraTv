<?php

namespace Modules\AuthorizeNet\Http\Controllers;

use App\FailedTranscations;
use App\Http\Controllers\PlaceOrderController;
use App\Http\Controllers\SubscriptionController;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Crypt;
use Jackiedo\DotenvEditor\Facades\DotenvEditor;
use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;

class AuthorizeNetController extends Controller
{
    
    public $api_login_id;
    public $transcation_key;

    /** @return payment key settings */

    public function __construct()
    {
        $this->api_login_id = env('API_LOGIN_ID');
        $this->transcation_key = env('TRANSCATION_KEY');
    }

    /**
     * Open keys setting view
     */
    public function getsettings(){
        return view('authorizenet::admin.tab');
    }


    /** @return check payment */

    public function payment(Request $request)
    {

        $plan_id = $request->plan_id;
        $amount = $request->amount;
        // Common setup for API credentials
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        $merchantAuthentication->setName(config('authorizenet.API_LOGIN_ID'));
        $merchantAuthentication->setTransactionKey(config('authorizenet.TRANSCATION_KEY'));
        $refId = 'ref' . time();
        // Create the payment data for a credit card
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber(str_replace(' ','',$request->number));
        // $creditCard->setExpirationDate( "2038-12");
        $expiry = explode('/', $request->expiry);
        $expiry = $expiry[1].'-'.$expiry[0];

        $creditCard->setExpirationDate(str_replace(" ",'',$expiry));
        $paymentOne = new AnetAPI\PaymentType();
        $paymentOne->setCreditCard($creditCard);
        // Create a transaction
        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType("authCaptureTransaction");
        $transactionRequestType->setAmount($amount);
        $transactionRequestType->setPayment($paymentOne);
        $request = new AnetAPI\CreateTransactionRequest();
        $request->setMerchantAuthentication($merchantAuthentication);
        $request->setRefId($refId);
        $request->setTransactionRequest($transactionRequestType);
        $controller = new AnetController\CreateTransactionController($request);


        if(env("AUTHORIZE_NET_MODE") === 'sandbox'){

            $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);

        }else{

            $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::PRODUCTION);
            
        }
       
        /** Final payment response and order proccess start */

        
        if ($response != null) 
        {

            $tresponse = $response->getTransactionResponse();
            
            if (($tresponse != null) && ($tresponse->getResponseCode() == "1")) {
                   
                    /* Placing new order */

                    $checkout = new SubscriptionController;
                    return $checkout->subscribe($payment_id=$tresponse->getTransId(),$payment_method='AuthorizeNet',$plan_id,$payment_status=1,$amount); 

            } else {

                \Log::error('Authorize Payment Error: Charge Credit Card ERROR :  Invalid response');

                return redirect('account/purchaseplan')->with('deleted', 'Payment Failed');

            }
        } else {

                \Log::error('Charge Credit Card Null response returned');

                return redirect('account/purchaseplan')->with('deleted', 'Payment Failed');

        }
        
    }

    public function saveKeys(Request $request)
    { 
        // return $request->AUTHORIZE_NET_MODE;
        $input = $request->all();
        $env_keys_save = DotenvEditor::setKeys([
            
            'API_LOGIN_ID' => $input['API_LOGIN_ID'], 
            'TRANSCATION_KEY' => $input['TRANSCATION_KEY'],
            'AUTHORIZE_NET_MODE' => $request->AUTHORIZE_NET_MODE == 1 ? "live" : "sandbox",
            'AUTHORIZE_NET_ENABLE' => $request->AUTHORIZE_NET_ENABLE ? 1 : 0

        ]);

        $env_keys_save->save();
        
        return back()->with('added','AuthorizeNet Payment keys updated !');

    }
}
