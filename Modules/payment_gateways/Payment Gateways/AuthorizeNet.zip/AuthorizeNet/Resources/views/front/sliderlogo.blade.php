<!-- This will append bkash payment logo on front page. -->
<!-- authorizenet owl item start -->
    @if(config('authorizenet.ENABLE') == 1 && Module::has('AuthorizeNet') && Module::find('AuthorizeNet')->isEnabled())
        <div class="payment-item">
            <a title="{{__('Authorize.Net Payment')}}" target="__blank" href="https://sandbox.authorize.net/"><img
                data-src="{{ Module::asset('authorizenet:logo/authorizenet.png') }}" class="owl-lazy img-fluid"></a>
        </div>              
    @endif
<!-- authorizenet owl item end -->