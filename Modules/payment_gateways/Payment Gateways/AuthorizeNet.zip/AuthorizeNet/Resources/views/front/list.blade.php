<!-- This will append Authorize.net payment tab on checkout page. -->
<!-- Authorize.net payment tab start -->
<!-- Mollie tab -->
<!--  && in_array('authorizenet',$currency_payments) -->
@if (env('AUTHORIZE_NET_ENABLE') == 1 && in_array('authorizenet',$currency_payments) )
    <li>
        <a href="#authorizeNet" data-toggle="tab">{{ __('staticwords.CheckoutWith') }} AuthorizeNet</a>
    </li>
@endif
<!-- end Mollie -->
<!-- Authorize.net payment tab end -->