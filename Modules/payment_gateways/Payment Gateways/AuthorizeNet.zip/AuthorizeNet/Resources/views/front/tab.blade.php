<!-- This will append Authorize.NET payment tab content on checkout page. -->
<!-- Authorize.NET payment tab content start -->
<div class="tab-pane" id="authorizeNet">
  <form method="POST" action="{{ route('auth.front.payment') }}" id="authnet-credit-card">
    @csrf

    <input type="hidden" name="actualtotal">

    <!-- Card Number -->
    <div class="form-group">
      <input class="form-control" placeholder="Card number" type="tel" name="number">
      @if ($errors->has('number'))
      <span class="invalid-feedback" role="alert">
        <strong>{{ $errors->first('number') }}</strong>
      </span>
      @endif
    </div>

    <!-- Username -->
    <div class="form-group">
      <input class="form-control" placeholder="Full name" type="text" name="name">
      @if ($errors->has('name'))
      <span class="invalid-feedback" role="alert">
        <strong>{{ $errors->first('name') }}</strong>
      </span>
      @endif
    </div>

    <!-- Card Expiry -->
    <div class="form-group">
      <input class="form-control" placeholder="YYYY" type="tel" name="expiry">
      @if ($errors->has('expiry'))
          <span class="invalid-feedback" role="alert">
          <strong>{{ $errors->first('expiry') }}</strong>
          </span>
      @endif
    </div>

    <!-- CVC -->
    <div class="form-group">
      <input class="form-control" placeholder="CVC" type="password" name="cvc">
      @if ($errors->has('cvc'))
      <span class="invalid-feedback" role="alert">
        <strong>{{ $errors->first('cvc') }}</strong>
      </span>
      @endif
    </div>

    <!-- Amount -->
    <input id="plan_amount" type="hidden" class="form-control" name="amount"
      value="{{$plan->amount - $session_amount}}">

    <!-- Plan ID -->
    <input id="plan_id" type="hidden" class="form-control" name="plan_id"
      value="{{$plan->id}}">

    <!-- Pay Now Button -->
      <div class="form-group">
      <button title="{{ __('Click to complete your payment') }} !" type="submit"
        class="btn btn-primary btn-lg btn-block" id="confirm-purchase">{{ __('Pay') }} <i
          ></i>
        
        {{ __('Now') }}</button>
    </div>

  </form>
</div>
