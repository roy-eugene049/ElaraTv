@extends('layouts.admin')
@section('title', __('adminstaticwords.APISettings'))

@section('content')
    <div class="admin-form-main-block mrg-t-40">
        <div class="row admin-form-block z-depth-1">
        
            <h6 class="form-block-heading apipadding">{{__('AuthorizeNet Payemnt Gateway')}}</h6>
            <br>
            
            <!-- This will append Authorize payment tab content on admin payment settings page. -->
            <!-- Authorize Payment tab content strat -->
            <form action="{{ route('authnet.payment.setting') }}" method="POST">
                @csrf

                <!-- Login ID -->
                <div class="form-group">
                    <label>{{ __("API LOGIN ID:") }} <span class="text-red">*</span></label>
                    <input required name="API_LOGIN_ID" value="{{ config('authorizenet.API_LOGIN_ID') }}" type="text"
                        class="form-control" placeholder="{{ __("Enter authorizenet login id") }}">
                </div>

                <!-- Transaction Key -->
                <div class="form-group">
                    <div class="search">
                        <label>{{ __("TRANSCATION KEY:") }} <span class="text-red">*</span></label>
                        <input required type="password" value="{{ config('authorizenet.TRANSCATION_KEY') }}" name="TRANSCATION_KEY"
                            placeholder="{{ __("enter TRANSCATION KEY") }}" id="TRANSCATION_KEY" type="password"
                            class="form-control">
                        <span toggle="#TRANSCATION_KEY" class="fa fa-fw fa-eye field-icon toggle-password2"></span>
                    </div>
                </div>

                <!-- Status -->
                <div class="form-group">
                    <label>{{ __("Status:") }}</label>
                    <br>
                    <label class="switch">
                        {!! Form::checkbox('AUTHORIZE_NET_ENABLE', 1, (config('authorizenet.ENABLE') == 1 ? "checked"  :""), ['id' => 'AUTHORIZE_NET_ENABLE','class' => 'checkbox-switch']) !!}
                        <span class="slider round"></span>
                    </label>
                    <br>
                    <small class="txt-desc">
                        {{__("(Active or deactive payment gateway by toggling it.)")}}
                    </small>
                </div>

                <!-- Live/Sandbox -->
                <div class="form-group">
                    <label>{{ __("SANDBOX Mode (TEST Mode):") }}</label>
                    <br>
                    <div class="make-switch">
                        {!! Form::checkbox('AUTHORIZE_NET_MODE', 1, (config('authorizenet.AUTHORIZE_NET_MODE') == 'live' ? "checked" : ""), ['id' => 'AUTHORIZE_NET_MODE', 'class' => 'bootswitch', "data-on-text"=>"Live", "data-off-text"=>"Sandbox", "data-size"=>"small"]) !!}
                    </div>
                   
                    <br>
                    <small class="txt-desc">
                        {{__("(Active or deactive test mode in payment gateway by toggling it.)")}}
                    </small>
                </div>

                <!-- Save Button -->
                <div class="modal-footer">
                    <div class="btn-group pull-right">
                        <a href={{url()->previous()}} class="btn btn-info"><i class="material-icons left">reply</i> {{__('Back')}}</a>
                        <button type="reset" class="btn btn-danger"><i class="material-icons left">toys</i> {{__('adminstaticwords.Reset')}}</button>
                        <button type="submit" class="btn btn-success"><i class="material-icons left">add_to_photos</i> {{__('Save Settings')}}</button>
                    </div>
                </div>
                <div class="clear-both"></div>


            </form>
            <!-- Authorize Payment tab content end -->
            
        </div>
    </div>
@endsection

@section('custom-script')

  <script>

    $(".toggle-password2").click(function() 
    {
        $(this).toggleClass("fa-eye fa-eye-slash");
        var input = $($(this).attr("toggle"));
        if (input.attr("type") == "password") {
            input.attr("type", "text");
        } 
        else {
            input.attr("type", "password");
        }
    });

  </script>

@endsection